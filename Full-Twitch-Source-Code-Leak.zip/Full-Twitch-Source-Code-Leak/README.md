# Full-Twitch-Source-Code-Leak


We bring to you today an extremely poggers leak:

Twitch is an American video live streaming service that focuses on video game live streaming, including broadcasts of esports competitions, operated by Twitch Interactive, a subsidiary of Amazon.com, Inc.

Their community is also a disgusting toxic cesspool, so to foster more disruption and competition in the online video streaming space, we have completely pwned them, and in part one, are releasing the source code from almost 6,000 internal Git repositories, including:

> Streamer payouts over 3 years
> 5GB first folder is most relevant to see payouts
> Entirety of twitch.tv, with commit history going back to its early beginnings
> Mobile, desktop and video game console Twitch clients
> Various proprietary SDKs and internal AWS services used by Twitch
> Every other property that Twitch owns including IGDB and CurseForge
> An unreleased Steam competitor from Amazon Game Studios
> Twitch SOC internal red teaming tools (lol)

AND: Creator payout reports from 2019 until now. Find out how much your favorite streamer is really making!

Torrent (128GB): `magnet:?xt=urn:btih:N5BLZ6XECNEHHARHJOVQAS4W7TWRXCSI&dn=twitch-leaks-part-one&tr=udp%3A%2F%2Fopen.stealth.si%3A80%2Fannounce`<br>
Repository listing: https://dpaste.org/MvoM (dead)

Jeff Bezos paid $970 million for this, we're giving it away FOR FREE.

#DoBetterTwitch

INCLUDING THE TWITCH DATABASE!!
